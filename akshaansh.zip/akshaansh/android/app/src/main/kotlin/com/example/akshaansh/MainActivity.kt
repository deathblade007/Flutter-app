package com.example.akshaansh

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
