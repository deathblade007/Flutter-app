import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: QuizApp(),
      debugShowCheckedModeBanner: false, // Remove debug banner
    );
  }
}

class QuizApp extends StatefulWidget {
  @override
  _QuizAppState createState() => _QuizAppState();
}

class _QuizAppState extends State<QuizApp> {
  int _currentIndex = 0;
  int _score = 0;

  List<Map<String, dynamic>> _questions = [
    {
      'question': 'What is the capital of France?',
      'options': ['Berlin', 'Madrid', 'Paris', 'Rome'],
      'correctAnswer': 'Paris',
    },
    {
      'question': 'Which planet is known as the Red Planet?',
      'options': ['Mars', 'Venus', 'Jupiter', 'Saturn'],
      'correctAnswer': 'Mars',
    },
    {
      'question':
          'What percentage of the Earth\'s surface is covered by water?',
      'options': ['50%', '70%', '90%', '30%'],
      'correctAnswer': '70%',
    },
    {
      'question': 'Which is the largest rainforest in the world?',
      'options': [
        'Amazon Rainforest',
        'Congo Rainforest',
        'Daintree Rainforest',
        'Sundarbans'
      ],
      'correctAnswer': 'Amazon Rainforest',
    },
    {
      'question': 'What is the process by which plants make their own food?',
      'options': [
        'Photosynthesis',
        'Respiration',
        'Fermentation',
        'Transpiration'
      ],
      'correctAnswer': 'Photosynthesis',
    },
    // Add more questions here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Quiz App', style: TextStyle(color: Colors.white), // Set text color
        ),
        backgroundColor: Colors.blue,
      ),
      body: _currentIndex < _questions.length
          ? QuizScreen(
              question: _questions[_currentIndex],
              onAnswerSelected: (String answer) {
                if (answer == _questions[_currentIndex]['correctAnswer']) {
                  // Increment the score for correct answers
                  setState(() {
                    _score++;
                  });
                }

                setState(() {
                  _currentIndex++;
                });
              },
            )
          : ResultScreen(score: _score, totalQuestions: _questions.length),
    );
  }
}

class QuizScreen extends StatelessWidget {
  final Map<String, dynamic> question;
  final Function(String) onAnswerSelected;

  QuizScreen({required this.question, required this.onAnswerSelected});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            question['question'],
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.center,
          ),
        ),
        SizedBox(height: 20),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: (question['options'] as List<String>).map((option) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: ElevatedButton(
                onPressed: () => onAnswerSelected(option),
                child: Text(option),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final int totalQuestions;

  ResultScreen({required this.score, required this.totalQuestions});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Quiz Completed!',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Text(
            'Your Score: $score out of $totalQuestions',
            style: TextStyle(fontSize: 18),
          ),
        ],
      ),
    );
  }
}